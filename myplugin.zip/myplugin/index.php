<?php
/*
Plugin Name: First Plugin
Plugin URI: https://youcode.ma/
Description: First Plugin
Author: Otmane Maacha
Version: 1.0
Author URI: https://www.github.com/maacha98otmane
*/

if (!defined('ABSPATH')) {
    exit;
}
require_once ABSPATH.'wp-config.php';
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD);
mysqli_select_db($connection, DB_NAME);

function newTableData()
{
    global $connection;

    $sql = 'CREATE TABLE Emails(id int NOT NULL PRIMARY KEY AUTO_INCREMENT, email varchar(255) NOT NULL)';
    $result = mysqli_query($connection, $sql);

    return $result;
}
if ($connection == true) {
    newTableData();
}
function footer_plugin_page()
{
    $page_title = 'Footer Editeur';
    $menu_title = 'Editeur Footer';
    $capatibily = 'manage_options';
    $slug = 'footer-plugin';
    $callback = 'callfooter';
    $icon = 'dashicons-shortcode';
    $position = 65;

    add_menu_page($page_title, $menu_title, $capatibily, $slug, $callback, $icon, $position);
}
add_action('admin_menu', 'footer_plugin_page');

function callfooter()
{
    include_once 'footer.php';
}

if (get_option('themeft') == 1) {
    function your_function()
    {
        echo"
    <footer class='text-center text-white' style='background:".get_option('colorbg')."'>
      <div class='container p-4'>
        <section class='mb-4'>
          <a class='btn btn-outline-light btn-floating m-1' href='".get_option('fb_link')."' role='button'
            ><i class='fa fa-facebook-f'></i
          ></a>
    
          <a class='btn btn-outline-light btn-floating m-1' href='".get_option('twitter_link')."' role='button'
            ><i class='fa fa-twitter'></i
          ></a>
    
          <a class='btn btn-outline-light btn-floating m-1' href='#!' role='button'
            ><i class='fa fa-google'></i
          ></a>
    
          <a class='btn btn-outline-light btn-floating m-1' href='".get_option('insta_link')."' role='button'
            ><i class='fa fa-instagram'></i
          ></a>
          <a class='btn btn-outline-light btn-floating m-1' href='".get_option('github_link')."' role='button'
            ><i class='fa fa-github'></i
          ></a>
        </section>    
        <section class=''>
          <form action='POST'>
            <div class='row d-flex justify-content-center'>
              <div class='col-auto'>
                <p class='pt-2'>
                  <strong>Sign up for our newsletter</strong>
                </p>
              </div>
              <div class='col-md-5 col-12'>
                <div class='form-outline form-white mb-4'>
                  <input type='email' name='email' placeholder='Email address' class='form-control' />
                </div>
              </div>
              <div class='col-auto'>
                <button type='submit' name='submitcheck' class='btn btn-outline-light mb-4'>
                  Subscribe
                </button>
              </div>
            </div>
          </form>
        </section>
    
        <section class='mb-4'>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt distinctio earum
            repellat quaerat voluptatibus placeat nam, commodi optio pariatur est quia magnam
            eum harum corrupti dicta, aliquam sequi voluptate quas.
          </p>
        </section>
      </div>    
      <div class='text-center p-3' style='background-color: rgba(0, 0, 0, 0.2);'>
        © 2021 Copyright:
        <a class='text-white' href='https://www.youcode.ma/'>".get_bloginfo('name').'</a>
      </div>
     
    </footer>
    ';
    }
    add_action('wp_footer', 'your_function');

    if (isset($_POST['submitcheck'])) {
        $email = $_POST['email'];
        print_r($email);
        die('dfd');
        form($email);
    }
    function form($email)
    {
        global $connection;

        $sql = "INSERT INTO Emails(email) VALUES ('$email')";
        $result = mysqli_query($connection, $sql);

        return $result;
    }
} else {
    function your_ftc()
    {
        echo"
    <footer class='text-center text-white' style='background:".get_option('colorbg')."'>
  <div class='container p-4 pb-0'>
    <section class='mb-4'>
      <a class='btn btn-outline-light btn-floating m-1' href='".get_option('fb_link')."' role='button'
        ><i class='fa fa-facebook-f'></i
      ></a>

      <a class='btn btn-outline-light btn-floating m-1' href='".get_option('twitter_link')."' role='button'
        ><i class='fa fa-twitter'></i
      ></a>

      <a class='btn btn-outline-light btn-floating m-1' href='".get_option('insta_link')."' role='button'
        ><i class='fa fa-instagram'></i
      ></a>

      <a class='btn btn-outline-light btn-floating m-1' href='".get_option('github_link')."' role='button'
        ><i class='fa fa-github'></i
      ></a>
    </section>
  </div>

  <div class='text-center p-3' style='background-color: rgba(0, 0, 0, 0.2);'>
    © 2021 Copyright:
    <a class='text-white' href='https://www.youcode.ma/'>".get_bloginfo('name').'</a>
  </div>
</footer>
    
    ';
    }
    add_action('wp_footer', 'your_ftc');
}

?>

