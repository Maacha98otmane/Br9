<?php
if (!defined('ABSPATH')) {
    exit;
}

global $variable1;
global $variable2;
global $variable3;
global $variable4;
global $variable5;
global $variable6;

    if (isset($_POST['wp__submit'])) {
        wp__opt();
    }
    function wp__opt()
    {
        $instalink = $_POST['instagramlink'];
        $facebooklink = $_POST['facebooklink'];
        $twitterlink = $_POST['twitterlink'];
        $githublink = $_POST['githublink'];
        $color = $_POST['color'];
        $theme = $_POST['theme'];
        global $variable1;
        if (get_option('insta_link') != trim($instalink)) {
            $variable1 = update_option('insta_link', trim($instalink));
        }
        global $variable2;

        if (get_option('fb_link') != trim($facebooklink)) {
            $variable2 = update_option('fb_link', trim($facebooklink));
        }
        global $variable3;

        if (get_option('twitter_link') != trim($twitterlink)) {
            $variable3 = update_option('twitter_link', trim($twitterlink));
        }
        global $variable4;

        if (get_option('github_link') != trim($githublink)) {
            $variable4 = update_option('github_link', trim($githublink));
        }
        global $variable5;

        if (get_option('colorbg') != trim($color)) {
            $variable5 = update_option('colorbg', trim($color));
        }
        global $variable6;

        if (get_option('themeft') != trim($theme)) {
            $variable6 = update_option('themeft', trim($theme));
        }
    }
?>
<div class="wrap">
  <div id="icon-options-general" class="icon32"> <br>
  </div>
  <h2>Footer Settings</h2>
  <?php if (isset($_POST['wp__submit']) && ($variable1 || $variable2 || $variable3 || $variable4 || $variable5 || $variable6)):?>
  <div id="message" class="updated below-h2">
    <p>Content updated successfully</p>
  </div>
  <?php endif; ?>
  <div class="metabox-holder">
    <div class="postbox">
      <h3><strong>Enter Social link and click on save button.</strong></h3>
      <form method="post" action="" style="padding: 20px;">
        <table class="form-table">
        <tr>
            <th><label for="theme">Choose a Theme:</label></th>
            <td><select name="theme" id="theme">
                <option value="">--Please choose a Theme--</option>
                <option value="1" selected="selected">1</option>
                <option value="2">2</option>
              </select></td>
          </tr>
        <tr>
            <th><label for="color">Choose a Color:</label></th>
            <td><select name="color" id="color">
                <option value="">--Please choose a color--</option>
                <option value="red">red</option>
                <option value="dark" selected="selected">dark</option>
                <option value="white">white</option>
                <option value="pink">pink</option>
                <option value="yellow">yellow</option>
              </select></td>
          </tr>
          <tr>
            <th scope="row">Your Instagram Link</th>
            <td><input type="text" name="instagramlink" value="<?php echo get_option('insta_link'); ?>"
                style="width:350px;" /></td>
          </tr>
          <tr>
            <th scope="row">Your Facebook Link</th>
            <td><input type="text" name="facebooklink" value="<?php echo get_option('fb_link'); ?>"
                style="width:350px;" /></td>
          </tr>
          <tr>
            <th scope="row">Your Twitter Link</th>
            <td><input type="text" name="twitterlink" value="<?php echo get_option('twitter_link'); ?>"
                style="width:350px;" /></td>
          </tr>
          <tr>
            <th scope="row">Your Github Link</th>
            <td><input type="text" name="githublink" value="<?php echo get_option('github_link'); ?>"
                style="width:350px;" /></td>
          </tr>
          
          <tr>
            <th scope="row">&nbsp;</th>
            <td style="padding-top:10px;  padding-bottom:10px;">
              <input type="submit" name="wp__submit" value="Save changes" class="button-primary" />
            </td>
          </tr>
        </table>
      </form>
    </div>
  </div>
</div>